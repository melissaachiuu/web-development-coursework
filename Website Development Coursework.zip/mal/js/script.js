document.getElementById('payment-form').addEventListener('submit', function (e) {
    e.preventDefault();
  
    const cardNumber = document.getElementById('cardNumber').value.replace(/\s+/g, '');
    const expiry = document.getElementById('expiry').value;
    const cvv = document.getElementById('cvv').value;
    const messageDiv = document.getElementById('message');
  
    messageDiv.textContent = ''; // Clear previous messages
  
    // Validation 1: 16 digits
    if (!/^\d{16}$/.test(cardNumber)) {
      return showError('Card number must be exactly 16 digits.');
    }
  
    // Validation 2: Mastercard prefix (51-55)
    const prefix = parseInt(cardNumber.slice(0, 2), 10);
    if (prefix < 51 || prefix > 55) {
      return showError('Card number must start with 51 to 55 (Mastercard).');
    }
  
    // Validation 3: Expiry check
    const [expMonth, expYear] = expiry.split('/');
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear() % 100; // last two digits
    const currentMonth = currentDate.getMonth() + 1; // JS months are 0-based
  
    if (!/^\d{2}\/\d{2}$/.test(expiry)) {
      return showError('Expiry date must be in MM/YY format.');
    }
  
    const expMonthNum = parseInt(expMonth, 10);
    const expYearNum = parseInt(expYear, 10) + 2000;
  
    if (expMonthNum < 1 || expMonthNum > 12) {
      return showError('Invalid expiry month.');
    }
  
    if (
      expYearNum < currentDate.getFullYear() ||
      (expYearNum === currentDate.getFullYear() && expMonthNum < currentMonth)
    ) {
      return showError('Card is expired.');
    }
  
    // Validation 4: CVV 3 or 4 digits
    if (!/^\d{3,4}$/.test(cvv)) {
      return showError('CVV must be 3 or 4 digits.');
    }
  
    // Prepare data
    const postData = {
      master_card: Number(cardNumber),
      exp_year: expYearNum,
      exp_month: expMonthNum,
      cvv_code: cvv
    };
  
    // Send POST request
    fetch('https://mudfoot.doc.stu.mmu.ac.uk/node/api/creditcard', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(postData)
    })
      .then(response => {
        if (!response.ok) {
          return response.json().then(err => {
            throw new Error(err.message || 'Server error');
          });
        }
        return response.json();
      })
      .then(data => {
        // Save the card number for use on success page
        localStorage.setItem('cardNumber', cardNumber);
  
        // Redirect to the success page
        window.location.href = 'success.html';
      })
      .catch(err => {
        showError(err.message || 'Payment failed. Please check your details and try again.');
      });
  
    function showError(msg) {
      messageDiv.textContent = msg;
      messageDiv.style.color = 'red';
    }
  });
  

